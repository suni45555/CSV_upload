using {staging.ZPTM_KBAN_MATCFG} from '../db/schema';

service StagingService {
    entity MaterialConfig as projection on ZPTM_KBAN_MATCFG;
    action uploadExcel(base64 : LargeString) returns String;
}
